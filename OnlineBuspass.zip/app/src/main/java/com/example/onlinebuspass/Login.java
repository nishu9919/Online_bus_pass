package com.example.onlinebuspass;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Login<databaseReference> extends AppCompatActivity {
    DatabaseReference databaseReference;
    
    private Button button,button1;
    //private EditText email,password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //databaseReference = FirebaseDatabase.getInstance().getReference("login");


        //email=(EditText)findViewById(R.id.email);
        //password =(EditText)findViewById(R.id.editText2);

        button = (Button)findViewById(R.id.reg);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openMainMenu();
            }
        });


        button1 = (Button)findViewById(R.id.register);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openRegister();
            }
        });
        //log();
    }

    public void openMainMenu()
            {
            Intent intent=new Intent(this,MainMenu.class);
            startActivity(intent);
            }



    public  void openRegister()
    {
        Intent intent=new Intent(this,Register.class);
        startActivity(intent);
    }
    
   /* public void log()
    {
        String Email = email.getText().toString();
        String Password = password.getText().toString();
        
        if(!TextUtils.isEmpty(Email) && !TextUtils.isEmpty(Password)) 
        {
        String id = databaseReference.push().getKey();
        Login loginn = new Login(id,Email,Password);
        
        databaseReference.child(id).setValue(loginn);
        email.setText("");
        password.setText("");
        }
        
        else
        {
            Toast.makeText(Login.this,"Please Enter the email id and password",Toast.LENGTH_LONG).show();
            
        }
    }*/
    
}
