package com.example.onlinebuspass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PassMenu extends AppCompatActivity {
    private Button button1,button2,button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_menu);

        button1 = (Button)findViewById(R.id.stubutton);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openApplyOrRenew();
            }
        });

        button2 = (Button)findViewById(R.id.serbutton);
        button2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v){
                openApplyOrRenew();
            }
        });

        button3 = (Button)findViewById(R.id.senbutton);
        button3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v){
                openApplyOrRenew();
            }
        });

    }
    public void openApplyOrRenew()
    {
        Intent intent = new Intent(this, ApplyRenew.class);
        startActivity(intent);
    }

}
