package com.example.onlinebuspass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ApplyRenew extends AppCompatActivity {
    private Button button1,button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_renew);

        button1 = (Button)findViewById(R.id.new_pass);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openFrom1();
            }
        });

        button = (Button)findViewById(R.id.renew);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openRenew();
            }
        });
    }

    public void openFrom1()
    {
        Intent intent=new Intent(this,AppForm1.class);
        startActivity(intent);
    }

    public void openRenew()
    {
        Intent intent=new Intent(this,Renew.class);
        startActivity(intent);
    }

}



