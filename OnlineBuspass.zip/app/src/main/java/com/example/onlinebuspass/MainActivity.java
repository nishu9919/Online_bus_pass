package com.example.onlinebuspass;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureImageButton();

    }


    private void configureImageButton()
    {
        ImageButton btn = (ImageButton) findViewById(R.id.imageButton);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this,"Online Bus Pass",Toast.LENGTH_LONG).show();
                openActivity_login();
            }
        });
    }

    public void openActivity_login()
    {
        Intent intent=new Intent(this,Login.class);
        startActivity(intent);
    }

}
