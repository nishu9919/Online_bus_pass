package com.example.onlinebuspass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainMenu extends AppCompatActivity {
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        button = (Button)findViewById(R.id.passmenu);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openPassTypes();
            }
        });
    }

public void openPassTypes()
{
    Intent intent=new Intent(this,PassMenu.class);
    startActivity(intent);
}


}
