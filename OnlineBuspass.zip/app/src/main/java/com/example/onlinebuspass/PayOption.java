package com.example.onlinebuspass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PayOption extends AppCompatActivity {
    private Button button1,button2,button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_option);

        button1 = (Button)findViewById(R.id.gogglepay);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openGogglepay();
            }
        });

        button2 = (Button)findViewById(R.id.phonepay);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openPhonePay();
            }
        });

    }

    public void openGogglepay()
    {
        Intent intent = new Intent(this, Payment.class);
        startActivity(intent);
    }

    public void openPhonePay()
    {
        Intent intent = new Intent(this, PhonePay.class);
        startActivity(intent);
    }


}
